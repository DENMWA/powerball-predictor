# Ψ★ Powerball Predictor

This app predicts Powerball numbers using three modes:
- Mode A: Random & Score
- Mode B: Ψ-Guided Construction
- Mode C: Ψ★ Model 2.0 (Softmax, D1, Genetic filtering)
